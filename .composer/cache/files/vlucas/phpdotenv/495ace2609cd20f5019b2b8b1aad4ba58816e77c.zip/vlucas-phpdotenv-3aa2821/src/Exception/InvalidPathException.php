<?php

namespace Dotenv\Exception;

use InvalidArgumentException;

class InvalidPathException extends InvalidArgumentException implements ExceptionInterface
{
    //
}
